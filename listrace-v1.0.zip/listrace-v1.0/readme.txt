-----------------------
# README
-----------------------

Listrace is a bootstrap 3 framework based html5/css3 directory listing template.It will help developers to rapidly built a directory website


Template Info:
-----------------------
Name: 		Listrace - free directory template
Version: 	1.0
Author: 	ThemeSINE
Website: 	https://www.themesine.com/


Changelog:
-----------------------
Version 1.0 21-05-2018
- initial release 


Credits:
-----------------------
- Twitter Bootstrap http://getbootstrap.com
- jQuery http://jquery.org
- Modernizr https://modernizr.com/
- Sticky.js http://stickyjs.com/
- JQuery easing https://github.com/gdsmith/jquery.easing
- Bootsnav http://bootsnav.danurstrap.com/

License:
-----------------------
Free License - https://www.themesine.com/license/